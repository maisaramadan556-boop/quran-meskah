#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if command -v node >/dev/null 2>&1; then
  node --check assets/app.js
  node --check assets/about.js
  node --check service-worker.js
  echo "PASS JavaScript syntax (3 files)"
else
  echo "WARN Node.js not installed; JavaScript syntax checks skipped" >&2
fi

python3 - <<'PY'
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse
import gzip, json, re, hashlib, zipfile, os

root = Path('.')
quran = json.loads((root/'data/quran.json').read_text(encoding='utf-8'))
rec_data = json.loads((root/'data/reciters.json').read_text(encoding='utf-8'))
reciters = rec_data.get('reciters', [])
page_map = json.loads((root/'data/verse-to-page.json').read_text(encoding='utf-8'))
data_manifest = json.loads((root/'data/manifest.json').read_text(encoding='utf-8'))
web_manifest = json.loads((root/'manifest.webmanifest').read_text(encoding='utf-8'))

# Quran content integrity / catalog shape.
assert len(quran) == 114
assert [int(s['id']) for s in quran] == list(range(1,115))
ayah_count = sum(len(s.get('array', [])) for s in quran)
assert ayah_count == 6236, ayah_count
for surah in quran:
    assert surah.get('name') and surah.get('array')
    for n, verse in enumerate(surah['array'], 1):
        assert int(verse.get('id', -1)) == n
        text = verse.get('ar')
        assert isinstance(text, str) and text.strip(), f"Empty Quran verse {surah['id']}:{n}"
assert len(page_map) == 604 and page_map[0] == {'surah':1,'ayah':1}
assert data_manifest.get('app_version') == '7.0.0'
assert web_manifest.get('name') and ('القرآن الكريم' in web_manifest['name'] or 'مشكاة' in web_manifest['name'])
print(f'PASS Quran data: {len(quran)} surahs / {ayah_count} verses / 604 page starts')

# Reader and audio catalog integrity.
assert len(reciters) == 12
assert any(r.get('id') == 'nasser_al_qatami_mp3quran' for r in reciters)
assert all(r.get('riwayah') == 'hafs_an_asim' for r in reciters)
total_urls = 0
word_files, verse_files = [], []
for r in reciters:
    urls = r.get('audio', {}).get('surah_urls', {})
    assert set(urls) == {str(i) for i in range(1,115)}, f"Incomplete audio URLs: {r['id']}"
    assert all(str(url).startswith('https://') for url in urls.values()), f"Non-HTTPS URL: {r['id']}"
    total_urls += len(urls)
    timing = r.get('timing') or {}
    for key, collected in [('word_file',word_files), ('verse_file',verse_files)]:
        rel = timing.get(key)
        if rel:
            path = root / rel
            assert path.is_file(), f"Missing timing archive: {rel}"
            raw = gzip.decompress(path.read_bytes())
            obj = json.loads(raw)
            assert obj.get('_meta',{}).get('slug') == r['id'], f"Timing slug mismatch: {rel}"
            assert obj.get('_meta',{}).get('units') == 'ms'
            rows = obj.get('rows', [])
            assert rows, f"Empty timing rows: {rel}"
            for row in rows:
                assert isinstance(row, list) and len(row) >= 4
                assert isinstance(row[0], str) and re.fullmatch(r'\d{1,3}:\d{1,3}', row[0])
                start, end = int(row[1]), int(row[2])
                assert 0 <= start <= end
                if len(row) > 5 and isinstance(row[5], list):
                    prior_start = start
                    for word in row[5]:
                        assert len(word) >= 3
                        wi, ws, we = map(int, word[:3])
                        assert wi >= 1 and start <= ws <= we <= end
                        assert ws >= prior_start
                        prior_start = ws
            if key == 'word_file':
                primary = sum(1 for row in rows if len(row) > 3 and row[3] is True)
                assert primary == timing.get('primary_ayahs'), f"Primary ayah count mismatch: {r['id']}"
            collected.append(path)
assert total_urls == 1368
assert len(word_files) == 10 and len(verse_files) == 10
assert not list(root.rglob('*.mp3'))
assert next(r for r in reciters if r['id']=='raad_al_kurdi_mp3quran')['timing']['primary_ayahs'] == 6230
print(f'PASS audio/timing catalog: {len(reciters)} reciters / {total_urls} HTTPS links / 10 word + 10 verse archives')

# HTML IDs, local links, scripts and styles.
class PageParser(HTMLParser):
    def __init__(self):
        super().__init__(); self.ids=[]; self.refs=[]
    def handle_starttag(self, tag, attrs):
        d=dict(attrs)
        if d.get('id'): self.ids.append(d['id'])
        for k in ('href','src','poster'):
            if d.get(k): self.refs.append((tag,k,d[k]))

pages = {}
for name in ('index.html','about.html'):
    p = PageParser(); p.feed((root/name).read_text(encoding='utf-8')); pages[name]=p
    assert len(p.ids) == len(set(p.ids)), f"Duplicate IDs in {name}"
    for tag, attr, value in p.refs:
        v=value.strip()
        if not v or v.startswith(('#','data:','mailto:','tel:','javascript:')): continue
        parsed=urlparse(v)
        if parsed.scheme or parsed.netloc: continue
        local=(root / parsed.path)
        assert local.exists(), f"Broken local {attr} in {name}: {value}"
assert 'about.html' in [ref[2] for ref in pages['index.html'].refs]
assert 'index.html' in [ref[2] for ref in pages['about.html'].refs]
for name in ('index.html','about.html'):
    html=(root/name).read_text(encoding='utf-8')
    assert 'fonts.googleapis.com' not in html and 'fonts.gstatic.com' not in html
assert 'footer-about-bottom' in (root/'index.html').read_text(encoding='utf-8')
assert 'href="about.html"' in (root/'index.html').read_text(encoding='utf-8')
assert 'الإصدار <strong>٧</strong>' in (root/'about.html').read_text(encoding='utf-8')
about_js=(root/'assets/about.js').read_text(encoding='utf-8')
about_ids=set(pages['about.html'].ids)
about_used=set(re.findall(r"\$\(['\"]#([\w-]+)['\"]\)", about_js))
assert not (about_used-about_ids), f'Missing about page IDs: {sorted(about_used-about_ids)}'
assert 'العودة إلى المصحف' in (root/'about.html').read_text(encoding='utf-8')
# Ensure all app-required static element IDs are present.
app=(root/'assets/app.js').read_text(encoding='utf-8')
html_ids=set(pages['index.html'].ids)
used=set(re.findall(r"\$\(['\"]#([\w-]+)['\"]\)",app))
missing=sorted(x for x in used if x not in html_ids and not x.startswith('dynamic-'))
assert not missing, f"App queries IDs missing from index.html: {missing}"
print(f'PASS HTML/navigation: unique IDs, {len(used)} referenced app IDs resolved, local paths, footer About link')

# CSS/font/loading/accessibility expectations.
css=(root/'assets/styles.css').read_text(encoding='utf-8')
sw=(root/'service-worker.js').read_text(encoding='utf-8')
assert '--quran: "Noto Naskh Arabic", "Noto Naskh Arabic Local", serif;' in css
assert 'font-feature-settings: "kern" 1, "liga" 1, "calt" 1, "mark" 1, "mkmk" 1;' in css
assert '.quran-content' in css and 'line-height: 2.5;' in css
assert 'font-family: var(--quran);' in css
assert 'DEFAULT_QURAN_FONT_SIZE = 2.10' in app
assert "font: 'mishkat.font.v5'" in app
assert 'Math.min(4.2, Math.max(1.4, safeSize))' in app
init_block=app[app.index('async function initialize()'):app.index('function renderReciters(')]
assert 'document.fonts.load' in init_block and 'Noto Naskh Arabic' in init_block and 'Promise.race' in init_block and 'await document.fonts.ready' not in init_block
assert "mishkat-app-v7-final-local1" in sw
assert 'assets/fonts/noto-naskh-arabic-ar.woff2' in sw
assert 'href="about.html"' in (root/'index.html').read_text(encoding='utf-8')
assert 'الإصدار <strong>٧</strong>' in (root/'about.html').read_text(encoding='utf-8')
about_js=(root/'assets/about.js').read_text(encoding='utf-8')
about_ids=set(pages['about.html'].ids)
about_used=set(re.findall(r"\$\(['\"]#([\w-]+)['\"]\)", about_js))
assert not (about_used-about_ids), f'Missing about page IDs: {sorted(about_used-about_ids)}'
assert 'Noto Naskh Arabic' in (root/'about.html').read_text(encoding='utf-8')
for asset in ['assets/fonts/readex-pro-ar.woff2','assets/fonts/readex-pro-latin.woff2','assets/fonts/amiri-400-ar.woff2','assets/fonts/amiri-700-ar.woff2','assets/fonts/noto-naskh-arabic-ar.woff2','icons/logo.svg','icons/favicon.svg']:
    data=(root/asset).read_bytes()
    if asset.endswith('.woff2'):
        assert data[:4] == b'wOF2' and len(data)>1000, f'Invalid WOFF2 file: {asset}'
print('PASS font/accessibility: Noto Quran stack, GPOS mark/mkmk, 24px mobile default, 200% zoom, new storage/cache keys')

# Source package data was not altered during the repair.
source_zip=Path(os.environ['MISHKAT_BASELINE_ZIP']) if os.environ.get('MISHKAT_BASELINE_ZIP') else None
if source_zip and source_zip.is_file():
    with zipfile.ZipFile(source_zip) as z:
        for rel in ['quran-royal/data/quran.json','quran-royal/data/reciters.json']:
            current=(root/Path(rel).relative_to('quran-royal')).read_bytes()
            assert hashlib.sha256(current).digest() == hashlib.sha256(z.read(rel)).digest(), f'Changed source data: {rel}'
        for p in word_files + verse_files:
            rel='quran-royal/'+p.relative_to(root).as_posix()
            assert hashlib.sha256(p.read_bytes()).digest() == hashlib.sha256(z.read(rel)).digest(), f'Changed timing file: {rel}'
    print('PASS source preservation: Quran, reciter catalog and 20 timing archives unchanged')
else:
    print('INFO Set MISHKAT_BASELINE_ZIP to an earlier project ZIP to run optional byte-for-byte preservation checks')

# Font coverage and advanced shaping table check using the environment's installed Noto font.
try:
    from fontTools.ttLib import TTFont
    font_path=Path('/usr/share/fonts/truetype/noto/NotoNaskhArabic-Regular.ttf')
    if not font_path.exists():
        candidates=list(Path('/usr/share/fonts').rglob('NotoNaskhArabic-Regular.ttf'))
        font_path=candidates[0] if candidates else None
    if font_path:
        font=TTFont(font_path)
        cmap=set().union(*(set(t.cmap) for t in font['cmap'].tables))
        needed=set()
        for surah in quran:
            for verse in surah['array']: needed.update(map(ord,verse['ar']))
        missing=sorted(cp for cp in needed if cp not in cmap and cp not in (0x2009,))
        assert not missing, 'Noto missing Quran characters: '+', '.join(f'U+{x:04X}' for x in missing)
        features={r.FeatureTag for r in font['GPOS'].table.FeatureList.FeatureRecord}
        assert {'mark','mkmk'} <= features, f'Missing GPOS features: {features}'
        print(f'PASS Noto font inspection: {len(needed)} Quran characters covered; GPOS mark/mkmk available')
    else:
        print('WARN Local Noto system font file not found; external Google Fonts fallback is configured')
except ImportError:
    print('WARN fontTools not installed; advanced font-table inspection skipped')

# CSS parser validates stylesheet tokenization when available.
try:
    import tinycss2
    def check_rules(items, where='stylesheet'):
        for rule in items:
            assert rule.type != 'error', f'CSS parse error in {where}: {rule}'
            if rule.type == 'qualified-rule' or (rule.type == 'at-rule' and rule.lower_at_keyword in ('font-face','page')):
                declarations=tinycss2.parse_declaration_list(rule.content, skip_comments=True, skip_whitespace=True)
                for declaration in declarations:
                    assert declaration.type != 'error', f'CSS declaration error in {where}: {declaration}'
            elif rule.type == 'at-rule' and rule.content is not None:
                check_rules(tinycss2.parse_rule_list(rule.content, skip_comments=True, skip_whitespace=True), where+'/'+rule.lower_at_keyword)
    rules=tinycss2.parse_stylesheet(css, skip_comments=True, skip_whitespace=True)
    check_rules(rules)
    for local_url in re.findall(r'url\([\"\']?([^\"\')]+)', css):
        if local_url.startswith(('data:','http://','https://','#')): continue
        assert (root/'assets'/local_url).is_file(), f'Missing CSS asset: {local_url}'
    sw_head=sw.split('self.addEventListener',1)[0]
    precache=re.findall(r"'\./([^']+)'", sw_head)
    assert precache and all((root/path).is_file() for path in precache), 'A service-worker precache file is missing'
    print(f'PASS recursive CSS parser and local assets: {len(rules)} top-level rules; {len(precache)} precache files')
except ImportError:
    print('WARN tinycss2 not installed; CSS parser test skipped')

print('ALL AVAILABLE STATIC/DATA TESTS PASSED')
PY

python3 -m json.tool data/quran.json >/dev/null
python3 -m json.tool data/reciters.json >/dev/null
python3 -m json.tool data/verse-to-page.json >/dev/null
python3 -m json.tool manifest.webmanifest >/dev/null
echo "PASS JSON parse (Quran, reciters, page index, web manifest)"
