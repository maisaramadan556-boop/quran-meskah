// Mishkat v7 — local fonts and bundled Mushaf pages.
const CACHE_NAME = 'mishkat-app-v7-final-local1';
const APP_FILES = [
  './',
  './index.html',
  './about.html',
  './assets/styles.css',
  './assets/app.js',
  './assets/about.js',
  './assets/fonts/readex-pro-ar.woff2',
  './assets/fonts/readex-pro-latin.woff2',
  './assets/fonts/amiri-400-ar.woff2',
  './assets/fonts/amiri-700-ar.woff2',
  './assets/fonts/noto-naskh-arabic-ar.woff2',
  './manifest.webmanifest',
  './icons/favicon.svg',
  './icons/logo.svg',
  './data/quran.json',
  './data/reciters.json',
  './data/verse-to-page.json'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(APP_FILES))
      .catch(error => console.warn('Some app files could not be precached:', error))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(key =>
      (key.startsWith('mishkat-app-') && key !== CACHE_NAME) ||
      key === 'mishkat-quran-v3'
    ).map(key => caches.delete(key))))
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  // Data files change rarely: serve them from cache first, then network.
  if (url.pathname.includes('/data/')) {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match(request);
      if (cached) return cached;
      const response = await fetch(request);
      if (response.ok) {
        try { await cache.put(request, response.clone()); } catch (_) { /* quota */ }
      }
      return response;
    })());
    return;
  }

  // App shell, HTML, CSS and JS are network-first so a new deployment can
  // never be mixed with a stale cached copy. Cached files remain as the
  // offline fallback.
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    try {
      const response = await fetch(request);
      if (response.ok) {
        try { await cache.put(request, response.clone()); } catch (_) { /* quota */ }
      }
      return response;
    } catch (error) {
      const cached = await cache.match(request);
      if (cached) return cached;
      throw error;
    }
  })());
});
